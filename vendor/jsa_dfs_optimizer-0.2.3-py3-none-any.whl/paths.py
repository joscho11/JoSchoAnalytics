"""Filesystem contract. Raw inputs live in cowork_OS/workspace."""
from __future__ import annotations

import importlib.util
from pathlib import Path

SUBPROJECT_ROOT = Path(__file__).resolve().parents[1]
PROJECT_ROOT = SUBPROJECT_ROOT
ARTIFACTS = SUBPROJECT_ROOT / "artifacts"
OUTPUTS = SUBPROJECT_ROOT / "outputs"
NOTEBOOKS = SUBPROJECT_ROOT / "notebooks"
LOGS = SUBPROJECT_ROOT / "logs"
FIXTURES = SUBPROJECT_ROOT / "fixtures"
INACTIVE_SNAPSHOTS_PATH = LOGS / "inactive_snapshots.csv"
INACTIVES_PATH = LOGS / "inactives.csv"


def _load_ws():
    for parent in Path(__file__).resolve().parents:
        cand = parent / "workspace" / "paths.py"
        if cand.exists():
            spec = importlib.util.spec_from_file_location("cowork_workspace_paths", cand)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            return mod
    raise FileNotFoundError("workspace/paths.py not found")


WS = _load_ws()
SHARED_DATA = WS.NFL_RAW
SLEEPER_DIR = WS.SLEEPER_WEEKLY


def weekly_features_path() -> Path:
    """Locked weekly feature matrix. This repo overlays DK Classic labels on it."""
    path = (
        PROJECT_ROOT.parent
        / "weekly_projections_v2_prod"
        / "independent_model"
        / "artifacts"
        / "weekly_features_2021_2025.parquet"
    )
    if path.exists():
        return path
    raise FileNotFoundError(f"weekly features parquet not found: {path}")


def player_stats_path() -> Path:
    path = WS.NFLVERSE / "player_stats_1999_2025.parquet"
    if path.exists():
        return path
    raise FileNotFoundError(f"player_stats parquet not found: {path}")


def schedules_path() -> Path:
    path = WS.NFLVERSE / "schedules_1999_2025.parquet"
    if path.exists():
        return path
    raise FileNotFoundError(f"schedules parquet not found: {path}")


def nfl_2026_schedule_path() -> Path:
    """2026 REG slate. Has gameday, no gametime, no ESPN event id."""
    path = WS.NFL / "nfl_2026_schedule.csv"
    if path.exists():
        return path
    raise FileNotFoundError(f"2026 schedule csv not found: {path}")


def snap_counts_path() -> Path:
    path = WS.NFLVERSE / "snap_counts_2013_2025.parquet"
    if path.exists():
        return path
    raise FileNotFoundError(f"snap_counts parquet not found: {path}")


def weekly_cache_dir() -> Path:
    return WS.NFLVERSE / "weekly_cache"


def weekly_cache_file(name: str) -> Path:
    path = weekly_cache_dir() / name
    if path.exists():
        return path
    raise FileNotFoundError(f"weekly_cache file not found: {path}")


def rosters_path() -> Path:
    """Season rosters. Carries sleeper_id next to gsis_id, which is what makes
    identity a key join instead of a name match."""
    path = WS.NFLVERSE / "rosters_2011_2025.parquet"
    if path.exists():
        return path
    raise FileNotFoundError(f"rosters parquet not found: {path}")


def players_path() -> Path:
    """Player bios. Backs age, years_exp, draft_pick, and the identity map."""
    path = WS.NFLVERSE / "players.parquet"
    if path.exists():
        return path
    raise FileNotFoundError(f"players parquet not found: {path}")


def qbr_weekly_path() -> Path:
    """ESPN week-level QBR. Backs the intended-QB protocol ported from gameday."""
    path = SHARED_DATA / "qbr_week_level.parquet"
    if path.exists():
        return path
    raise FileNotFoundError(f"weekly QBR parquet not found: {path}")


DOWNLOADS = SUBPROJECT_ROOT / "data" / "downloads"

NGS_TYPES = ("receiving", "rushing")
PFR_TYPES = ("pass", "def")


def ngs_path(stat_type: str) -> Path:
    """NGS weekly, pulled via nflreadpy. Not in the shared cache yet.

    Filter `week == 0` out before use. NGS ships a season-summary row per player
    at week 0 and it will silently poison every window it reaches.
    """
    if stat_type not in NGS_TYPES:
        raise ValueError(f"ngs stat_type must be one of {NGS_TYPES}, got {stat_type!r}")
    return DOWNLOADS / f"ngs_{stat_type}.parquet"


def pfr_advstats_path(stat_type: str) -> Path:
    """PFR weekly advanced stats, pulled via nflreadpy. Available from 2018."""
    if stat_type not in PFR_TYPES:
        raise ValueError(f"pfr stat_type must be one of {PFR_TYPES}, got {stat_type!r}")
    return DOWNLOADS / f"pfr_advstats_week_{stat_type}.parquet"


def team_week_epa_path() -> Path:
    path = SHARED_DATA / "team_week_epa.parquet"
    if path.exists():
        return path
    raise FileNotFoundError(f"team_week_epa parquet not found: {path}")


def weather_path() -> Path:
    candidates = [
        WS.NFL / "nfl_weather_2014_2025.csv",
        PROJECT_ROOT.parent / "JoSchoAnalytics_private" / "betting" / "nfl_weather_2014_2025.csv",
        Path(WS.JSA_WEATHER),
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError("weather csv not found")


def allpro_path() -> Path:
    path = WS.NFL / "nfl_allpro_1997_2025.csv"
    if path.exists():
        return path
    raise FileNotFoundError(f"all-pro csv not found: {path}")


def coaching_file(name: str) -> Path:
    path = SHARED_DATA / "coaching" / name
    if path.exists():
        return path
    raise FileNotFoundError(f"coaching file not found: {path}")


def assert_layout() -> None:
    required = (SHARED_DATA, SLEEPER_DIR, ARTIFACTS, OUTPUTS, NOTEBOOKS)
    missing = [str(path) for path in required if not path.is_dir()]
    if missing:
        raise FileNotFoundError(f"Independent-model layout is incomplete: {missing}")
