"""Parse a DraftKings NFL Classic salary export."""
from __future__ import annotations

import re
from pathlib import Path

import pandas as pd

GAME_RE = re.compile(
    r"(?P<away>[A-Z]{2,3})@(?P<home>[A-Z]{2,3})\s+"
    r"(?P<date>\d{2}/\d{2}/\d{4})\s+"
    r"(?P<time>.+)"
)

RENAME = {
    "Position": "position",
    "Name + ID": "name_id",
    "Name": "name",
    "ID": "dk_id",
    "Salary": "salary",
    "TeamAbbrev": "team",
    "AvgPointsPerGame": "avg_pts",
    "Game Info": "game_info",
    "Roster Position": "roster_position",
    "Status": "status",
}

CLASSIC_POSITIONS = frozenset({"QB", "RB", "WR", "TE", "DST"})
INELIGIBLE_STATUSES = frozenset({"OUT", "O", "IR", "D", "PUP", "SUSP", "NFI"})


def parse_game_info(value) -> dict:
    text = "" if value is None or (isinstance(value, float) and pd.isna(value)) else str(value)
    m = GAME_RE.search(text)
    if not m:
        return {"away": "", "home": "", "slate_date": "", "kickoff": text}
    return {
        "away": m.group("away"),
        "home": m.group("home"),
        "slate_date": m.group("date"),
        "kickoff": m.group("time").strip(),
    }


def load_dk_salaries(path: str | Path, *, require_classic_template: bool = True) -> pd.DataFrame:
    raw = pd.read_csv(path)
    required = ["Position", "Name", "Salary", "TeamAbbrev"]
    if require_classic_template:
        required.extend(["Roster Position", "Game Info"])
    missing = [c for c in required if c not in raw.columns]
    if missing:
        raise ValueError(f"not a DK Classic export; missing {missing}")
    df = raw.rename(columns={k: v for k, v in RENAME.items() if k in raw.columns}).copy()
    df["salary"] = pd.to_numeric(df["salary"], errors="coerce")
    avg_pts = df["avg_pts"] if "avg_pts" in df.columns else pd.Series(0.0, index=df.index)
    df["avg_pts"] = pd.to_numeric(avg_pts, errors="coerce").fillna(0.0)
    parsed = df["game_info"].map(parse_game_info) if "game_info" in df.columns else [{}] * len(df)
    extra = pd.DataFrame(list(parsed), index=df.index)
    df = pd.concat([df, extra], axis=1)
    df["position"] = df["position"].astype(str).str.upper().str.strip()
    df["team"] = df["team"].astype(str).str.upper().str.strip()
    if "status" not in df.columns:
        df["status"] = ""
    df["status"] = df["status"].fillna("").astype(str).str.upper().str.strip()
    if "dk_id" not in df.columns:
        df["dk_id"] = ""
    df["dk_id"] = df["dk_id"].fillna("").astype(str).str.strip()
    if "name_id" not in df.columns:
        df["name_id"] = ""
    df["name_id"] = df["name_id"].fillna("").astype(str).str.strip()
    missing_token = df["name_id"].eq("") & df["dk_id"].ne("")
    df.loc[missing_token, "name_id"] = (
        df.loc[missing_token, "name"].astype(str)
        + " ("
        + df.loc[missing_token, "dk_id"]
        + ")"
    )
    df["player_key"] = df["dk_id"].where(
        df["dk_id"].ne(""),
        df["name"].astype(str) + "|" + df["team"] + "|" + df["position"],
    )
    return df.reset_index(drop=True)


def salary_eligibility(df: pd.DataFrame) -> pd.DataFrame:
    """Annotate rows that can legally enter the optimizer before projection matching."""
    out = df.copy()
    salary = pd.to_numeric(out.get("salary"), errors="coerce")
    status = out.get("status", pd.Series("", index=out.index)).fillna("").astype(str).str.upper()
    position = out.get("position", pd.Series("", index=out.index)).fillna("").astype(str).str.upper()
    roster_position = (
        out.get("roster_position", pd.Series("", index=out.index)).fillna("").astype(str).str.upper().str.strip()
    )
    roster_tokens = roster_position.map(lambda value: {token for token in value.split("/") if token})
    invalid_roster = roster_position.ne("") & pd.Series(
        ["CPT" in tokens or pos not in tokens for pos, tokens in zip(position, roster_tokens)],
        index=out.index,
    )
    reason = pd.Series("", index=out.index, dtype="string")
    reason = reason.mask(status.isin(INELIGIBLE_STATUSES), "unavailable:" + status)
    reason = reason.mask(reason.eq("") & (~position.isin(CLASSIC_POSITIONS)), "invalid_position")
    reason = reason.mask(reason.eq("") & invalid_roster, "invalid_roster_position")
    reason = reason.mask(reason.eq("") & (salary.isna() | salary.le(0)), "invalid_salary")
    reason = reason.mask(
        reason.eq("") & out.get("name", pd.Series("", index=out.index)).fillna("").astype(str).str.strip().eq(""),
        "missing_name",
    )
    out["salary_eligible"] = reason.eq("")
    out["salary_exclusion_reason"] = reason.fillna("")
    return out


def slate_summary(df: pd.DataFrame) -> dict:
    dates = sorted({d for d in df.get("slate_date", pd.Series(dtype=str)).dropna().unique() if d})
    kickoffs = sorted({k for k in df.get("kickoff", pd.Series(dtype=str)).dropna().unique() if k})
    games = sorted({
        f"{a}@{h}" for a, h in zip(df.get("away", []), df.get("home", []))
        if a and h
    })
    return {
        "n_rows": int(len(df)),
        "n_skill": int((df["position"] != "DST").sum()),
        "n_dst": int((df["position"] == "DST").sum()),
        "dates": dates,
        "kickoffs": kickoffs,
        "n_games": len(games),
        "games": games,
        "is_sunday_only": dates == ["09/13/2026"] or (len(dates) == 1 and len(kickoffs) <= 2),
    }
